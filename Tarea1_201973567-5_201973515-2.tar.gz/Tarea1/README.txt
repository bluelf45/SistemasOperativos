Nombre: Oscar Hernan Acevedo Bonvin Rol: 201973567-5 Paralelo: 200
Nombre: Juan Pablo Labbe Mersey Rol: 201973515-2 Paralelo: 200

la creacion del Laberinto esta en el archivo Main.c
El buscador de los .txt esta en el archivo Pregunta2.c

todo se compilo y testeo usando WSL Ubuntu 20.04 y un Notebook usando Pop OS 20.04
se compilo usando el comando make y ejecutando cada programa como ./ProgramName, donde ProgramName seria Main o Pregunta2. Se puede
ejecutar usando "make exec", solo si ya se hizo make para compilar los programas.
Para volver a ejecutar el programa se recomienda borrar la carpeta Laberinto.
